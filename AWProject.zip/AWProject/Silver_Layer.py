# Databricks notebook source
#service_credential = dbutils.secrets.get(scope="<secret-scope>",key="<service-credential-key>")

spark.conf.set("fs.azure.account.auth.type.awadls.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.awadls.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.awadls.dfs.core.windows.net", "d2632f75-a48f-4391-8035-086a4b4b8900")
spark.conf.set("fs.azure.account.oauth2.client.secret.awadls.dfs.core.windows.net", "qu48Q~QRruPa6QQX~V8brabIo5ekGBxhQLTa3c10")
spark.conf.set("fs.azure.account.oauth2.client.endpoint.awadls.dfs.core.windows.net", "https://login.microsoftonline.com/b0ddec57-bba0-4c34-948d-b2abed36583f/oauth2/token")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Reading

# COMMAND ----------

df_cal = spark.read.format("csv")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@awadls.dfs.core.windows.net/calendar/calendar.csv")

# COMMAND ----------

df_cus = spark.read.format("csv")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@awadls.dfs.core.windows.net/customers")

# COMMAND ----------

df_procat = spark.read.format("csv")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@awadls.dfs.core.windows.net/product_categories")

# COMMAND ----------

df_subcat = spark.read.format("csv")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@awadls.dfs.core.windows.net/product_subcategories")

# COMMAND ----------

df_pro= spark.read.format("csv")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@awadls.dfs.core.windows.net/products")

# COMMAND ----------

df_ret = spark.read.format("csv")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@awadls.dfs.core.windows.net/returns")

# COMMAND ----------

df_sales = spark.read.format("csv")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@awadls.dfs.core.windows.net/Sales")

# COMMAND ----------

df_ter = spark.read.format("csv")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@awadls.dfs.core.windows.net/territories")

# COMMAND ----------

df_sales.limit(5).display()

# COMMAND ----------

df_cal.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Transformation**

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Calendar

# COMMAND ----------

df_cal = df.withColumn("year", year(col("Date")))\
    .withColumn("month", month(col("Date")))
df_cal.limit(5).display()

# COMMAND ----------

df_cal.write.format("parquet")\
  .mode("overwrite")\
  .save("abfss://silver@awadls.dfs.core.windows.net/calender")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Customers

# COMMAND ----------

df_cus.limit(5).display()

# COMMAND ----------

df_cus.withColumn("FullName", concat(col("prefix"), lit(" "), col("FirstName"), lit(" "), col("LastName"))).limit(5).display()

# COMMAND ----------

df_cus = df_cus.withColumn("FullName", concat_ws(" ", col("prefix"), col("FirstName"), col("LastName")))
df_cus.limit(5).display()


# COMMAND ----------

df_cus.write.format("parquet")\
  .mode("overwrite")\
  .save("abfss://silver@awadls.dfs.core.windows.net/customers")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product_Categories

# COMMAND ----------

df_procat.limit(5).display()

# COMMAND ----------

df_procat.write.format("parquet")\
  .mode("overwrite")\
  .save("abfss://silver@awadls.dfs.core.windows.net/Product_Categories")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product_SubCategories

# COMMAND ----------

df_subcat.limit(5).display()

# COMMAND ----------

df_subcat.write.format("parquet")\
  .mode("overwrite")\
  .save("abfss://silver@awadls.dfs.core.windows.net/Product_SubCategories")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Products

# COMMAND ----------

df_pro.limit(5).display()

# COMMAND ----------

df_pro = df_pro.withColumn("SKUType", split(col("ProductSKU"), "-")[0])\
    .withColumn("NameType", split(col("ProductName"), " ")[0])

df_pro.limit(5).display()


# COMMAND ----------

df_pro.write.format("parquet")\
  .mode("overwrite")\
  .save("abfss://silver@awadls.dfs.core.windows.net/Products")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Returns

# COMMAND ----------

df_ret.limit(5).display()

# COMMAND ----------

df_ret.write.format("parquet")\
  .mode("overwrite")\
  .save("abfss://silver@awadls.dfs.core.windows.net/Returns")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Territories

# COMMAND ----------

df_ter.limit(5).display()

# COMMAND ----------

df_ter.write.format("parquet")\
  .mode("overwrite")\
  .save("abfss://silver@awadls.dfs.core.windows.net/Territories")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sales

# COMMAND ----------

df_sales.display()

# COMMAND ----------

df_sales = df_sales.withColumn("StockDate", to_timestamp(col("StockDate")))\
    .withColumn("OrderNumber", regexp_replace(col("OrderNumber"),'S','M'))\
    .withColumn("Multiple", col("OrderLineItem")*col("OrderQuantity"))
df_sales.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sales Analysis

# COMMAND ----------

df_sales.groupBy("OrderDate").agg(countDistinct("OrderNumber").alias("DistinctOrders")).display()


# COMMAND ----------

df_sales.write.format("parquet")\
  .mode("overwrite")\
  .save("abfss://silver@awadls.dfs.core.windows.net/Sales")

# COMMAND ----------

